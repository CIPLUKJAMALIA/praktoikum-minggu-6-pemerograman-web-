<?php

session_start();

require_once "../includes/auth.php";

require_once "../config/database.php";

$id = isset($_GET['id'])
    ? (int)$_GET['id']
    : 0;

$query = mysqli_query(
    $conn,
    "SELECT * FROM produk
     WHERE id = $id"
);

$produk = mysqli_fetch_assoc($query);

if (!$produk) {

    die("Produk tidak ditemukan.");

}

?>
<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Edit Produk — Izna Iland</title><link rel="stylesheet" href="../assets/style.css"></head>
<body><div class="navbar"><div class="container"><a href="index.php" class="brand"><span class="brand-mark">I</span> Izna Iland</a><a href="produk.php">Produk</a><a href="../index.php">Website</a><a href="logout.php" class="nav-cta">Logout</a></div></div>
<div class="container"><div class="admin-top"><div><p class="muted">Catalog management</p><h1>Edit Produk</h1></div></div><div class="card"><?php include "../includes/flash.php"; ?>
<form action="proses_produk.php" method="POST" enctype="multipart/form-data"><input type="hidden" name="aksi" value="edit"><input type="hidden" name="id" value="<?= $produk['id']; ?>">
<div class="form-grid"><div><label>Nama Produk</label><input type="text" name="nama" value="<?= htmlspecialchars($produk['nama']); ?>" required></div>
<div><label>Kategori</label><select name="kategori" required><option value="Cake" <?= $produk['kategori']=='Cake'?'selected':''; ?>>Cake</option><option value="Brownies" <?= $produk['kategori']=='Brownies'?'selected':''; ?>>Brownies</option><option value="Donat" <?= $produk['kategori']=='Donat'?'selected':''; ?>>Donat</option></select></div>
<div class="form-full"><label>Deskripsi</label><textarea name="deskripsi" rows="6" required><?= htmlspecialchars($produk['deskripsi']); ?></textarea></div>
<div><label>Harga</label><input type="number" name="harga" value="<?= $produk['harga']; ?>" required></div><div><label>Stok</label><input type="number" name="stok" value="<?= $produk['stok']; ?>" required></div>
<div class="form-full"><label>Ganti Gambar</label><input type="file" name="gambar" accept=".jpg,.jpeg,.png,.webp"></div></div>
<?php if($produk['gambar']): ?><p class="muted">Gambar saat ini:</p><img src="../uploads/produk/<?= htmlspecialchars($produk['gambar']); ?>" style="width:180px;height:130px;object-fit:cover;border-radius:15px"><?php endif; ?><br><br>
<button type="submit" class="btn">Update Produk</button> <a href="produk.php" class="btn btn-secondary">Kembali</a></form></div></div><footer class="footer">Izna Iland Admin Panel</footer></body></html>
