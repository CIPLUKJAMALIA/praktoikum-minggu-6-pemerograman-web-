<?php
require_once "../includes/auth.php";
require_once "../config/database.php";
$total_produk = mysqli_query($conn,"SELECT COUNT(*) AS total FROM produk");
$data_produk = mysqli_fetch_assoc($total_produk);
$total_kategori = mysqli_query($conn,"SELECT COUNT(DISTINCT kategori) AS total FROM produk");
$data_kategori = mysqli_fetch_assoc($total_kategori);
$recent = mysqli_query($conn,"SELECT * FROM produk ORDER BY id DESC LIMIT 5");
?>
<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard — Izna Iland</title><link rel="stylesheet" href="../assets/style.css"></head><body>
<div class="navbar"><div class="container"><a href="index.php" class="brand"><span class="brand-mark">I</span> Izna Iland <span class="badge">ADMIN</span></a><a href="produk.php">Produk</a><a href="../index.php">Website</a><a href="logout.php" class="nav-cta">Logout</a></div></div>
<div class="container"><div class="admin-top"><div><p class="muted">Control center</p><h1>Dashboard Admin</h1><p class="muted">Selamat datang, <strong><?= htmlspecialchars($_SESSION['admin_nama']); ?></strong>.</p></div><a href="tambah.php" class="btn">+ Tambah Produk</a></div>
<div class="stats"><div class="stat"><div class="label">Total Produk</div><div class="value"><?= $data_produk['total']; ?></div></div><div class="stat"><div class="label">Kategori</div><div class="value"><?= $data_kategori['total']; ?></div></div><div class="stat"><div class="label">Status</div><div class="value">Aktif</div></div></div>
<div class="card" style="margin-top:20px"><div class="section-head"><div><h2>Produk terbaru</h2><p>Ringkasan katalog Izna Iland.</p></div><a href="produk.php" class="btn btn-secondary btn-small">Kelola semua</a></div>
<div class="table-wrap"><table><tr><th>Produk</th><th>Kategori</th><th>Harga</th><th>Stok</th></tr>
<?php while($row=mysqli_fetch_assoc($recent)): ?><tr><td><strong><?= htmlspecialchars($row['nama']); ?></strong></td><td><span class="badge"><?= htmlspecialchars($row['kategori']); ?></span></td><td>Rp <?= number_format($row['harga'],0,',','.'); ?></td><td><?= $row['stok']; ?></td></tr><?php endwhile; ?>
</table></div></div></div><footer class="footer">Izna Iland Admin Panel</footer></body></html>