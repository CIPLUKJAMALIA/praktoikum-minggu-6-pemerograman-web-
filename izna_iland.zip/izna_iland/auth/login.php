<?php
session_start();
if (isset($_SESSION['admin_id'])) {
    header("Location: ../admin/index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login Admin - Izna Iland</title>
<link rel="stylesheet" href="../assets/style.css">
</head>
<body class="auth-page">
<div class="auth-shell">
    <section class="auth-brand">
        <div class="brand-mark">I</div>
        <h1>Izna Iland</h1>
        <p>Ruang manajemen toko yang elegan untuk mengelola katalog produk dengan lebih rapi.</p>
        <ul class="auth-points">
            <li>✦ Kelola produk dengan CRUD</li>
            <li>✦ Dashboard admin yang ringkas</li>
            <li>✦ Upload gambar produk</li>
        </ul>
    </section>
    <section class="auth-form">
        <span class="badge">ADMIN AREA</span>
        <h2>Selamat datang kembali</h2>
        <p>Masuk untuk mengelola Izna Iland.</p>
        <?php
        if (isset($_SESSION['error'])) {
            echo '<div class="alert" style="background:#fff0f3;color:#a8324c;border-color:#ffd6df">'
                . htmlspecialchars($_SESSION['error']) . '</div>';
            unset($_SESSION['error']);
        }
        ?>
        <form action="proses_login.php" method="POST">
            <label>Username</label>
            <input type="text" name="username" placeholder="Masukkan username" autocomplete="username" required>
            <label>Password</label>
            <input type="password" name="password" placeholder="Masukkan password" autocomplete="current-password" required>
            <button type="submit" class="btn" style="width:100%">Masuk ke Dashboard →</button>
        </form>
        <a class="auth-back" href="../index.php">← Kembali ke website</a>
    </section>
</div>
</body>
</html>