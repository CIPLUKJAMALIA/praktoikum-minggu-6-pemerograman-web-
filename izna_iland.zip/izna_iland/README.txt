IZNA ILAND - PROJECT CRUD PHP + LARAGON
==========================================

Struktur:
toko_kue/
├── admin/              # dashboard + CRUD produk
├── assets/             # CSS premium lavender
├── auth/               # login/logout
├── config/             # koneksi database
├── includes/           # proteksi session + flash
├── uploads/produk/     # gambar produk
├── index.php            # halaman utama
├── produk.php           # katalog
├── detail.php           # detail produk
├── tentang.php          # tentang Izna Iland
└── toko_kue.sql         # database phpMyAdmin

LOGIN DEFAULT:
username: admin
password: admin123

CARA MENJALANKAN:
1. Buka Laragon, Start All.
2. Salin folder toko_kue ke C:\laragon\www\
3. Buka http://localhost/phpmyadmin
4. Buat database bernama toko_kue.
5. Import toko_kue.sql.
6. Buka http://localhost/toko_kue/
7. Admin: http://localhost/toko_kue/auth/login.php

CATATAN:
- Konsep CRUD dosen dipertahankan: tambah, edit, hapus, upload gambar,
  pencarian, filter, pagination, session login, dan password_hash/password_verify.
- Perubahan utama ada pada tampilan/branding/CSS dan layout halaman.
- Jangan hapus folder uploads/produk.
