<?php
require_once "config/database.php";
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$query = mysqli_query($conn, "SELECT * FROM produk WHERE id = $id");
$produk = mysqli_fetch_assoc($query);
if (!$produk) die("Produk tidak ditemukan.");
?>
<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($produk['nama']); ?> — Izna Iland</title><link rel="stylesheet" href="assets/style.css"></head><body>
<div class="navbar"><div class="container"><a href="index.php" class="brand"><span class="brand-mark">I</span> Izna Iland</a><a href="produk.php">Produk</a><a href="tentang.php">Tentang</a><a href="auth/login.php" class="nav-cta">Admin Login</a></div></div>
<section class="section"><div class="container"><div class="detail-grid">
<div><?php if($produk['gambar']): ?><img class="detail-image" src="uploads/produk/<?= htmlspecialchars($produk['gambar']); ?>" alt="<?= htmlspecialchars($produk['nama']); ?>"><?php endif; ?></div>
<div><span class="badge"><?= htmlspecialchars($produk['kategori']); ?></span><h1 style="font-size:clamp(2rem,5vw,3.5rem);line-height:1.05"><?= htmlspecialchars($produk['nama']); ?></h1>
<p class="muted"><?= nl2br(htmlspecialchars($produk['deskripsi'])); ?></p><div class="price" style="font-size:1.7rem">Rp <?= number_format($produk['harga'],0,',','.'); ?></div>
<p><strong>Stok:</strong> <?= $produk['stok']; ?> pcs</p><a href="produk.php" class="btn btn-secondary">← Kembali ke produk</a></div>
</div></div></section><footer class="footer">© <?= date('Y'); ?> Izna Iland</footer></body></html>