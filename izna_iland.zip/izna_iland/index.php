<?php
require_once "config/database.php";
$query = mysqli_query($conn, "SELECT * FROM produk ORDER BY id DESC LIMIT 6");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Izna Iland — Sweet Moments</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="navbar"><div class="container">
    <a href="index.php" class="brand"><span class="brand-mark">I</span> Izna Iland</a>
    <a href="produk.php">Produk</a><a href="tentang.php">Tentang</a>
    <a href="auth/login.php" class="nav-cta">Admin Login</a>
</div></div>
<section class="hero"><div class="container hero-content">
    <span class="eyebrow">✦ Sweet moments, beautifully made</span>
    <h1>Rasa manis untuk <span class="gradient-text">momen istimewa.</span></h1>
    <p>Selamat datang di Izna Iland — tempat untuk menemukan kue, brownies, dan donat pilihan yang dibuat untuk menemani setiap cerita.</p>
    <div class="hero-actions"><a href="produk.php" class="btn">Jelajahi Produk →</a><a href="tentang.php" class="btn btn-secondary">Kenal Izna Iland</a></div>
</div></section>
<section class="section"><div class="container">
    <div class="section-head"><div><h2>Produk pilihan</h2><p>Koleksi terbaru yang tersedia di Izna Iland.</p></div><a href="produk.php" class="btn btn-secondary btn-small">Lihat semua</a></div>
    <div class="grid">
    <?php while ($row = mysqli_fetch_assoc($query)): ?>
        <article class="card product-card">
            <?php if ($row['gambar']): ?><img src="uploads/produk/<?= htmlspecialchars($row['gambar']); ?>" class="product-image" alt="<?= htmlspecialchars($row['nama']); ?>"><?php endif; ?>
            <div class="product-body"><span class="badge"><?= htmlspecialchars($row['kategori']); ?></span>
            <h3><?= htmlspecialchars($row['nama']); ?></h3><p><?= htmlspecialchars($row['deskripsi']); ?></p>
            <div class="price">Rp <?= number_format($row['harga'],0,',','.'); ?></div>
            <br><a href="detail.php?id=<?= $row['id']; ?>" class="btn btn-small">Lihat detail</a></div>
        </article>
    <?php endwhile; ?>
    </div>
</div></section>
<footer class="footer">© <?= date('Y'); ?> Izna Iland · Crafted for sweet moments.</footer>
</body></html>