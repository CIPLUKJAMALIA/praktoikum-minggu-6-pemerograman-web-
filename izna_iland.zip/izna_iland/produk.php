<?php
require_once "config/database.php";
$keyword = $_GET['keyword'] ?? '';
if ($keyword != '') {
    $keyword_safe = mysqli_real_escape_string($conn, $keyword);
    $query = mysqli_query($conn, "SELECT * FROM produk WHERE nama LIKE '%$keyword_safe%' ORDER BY id DESC");
} else {
    $query = mysqli_query($conn, "SELECT * FROM produk ORDER BY id DESC");
}
?>
<!DOCTYPE html><html lang="id"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Produk — Izna Iland</title><link rel="stylesheet" href="assets/style.css"></head><body>
<div class="navbar"><div class="container">
<a href="index.php" class="brand"><span class="brand-mark">I</span> Izna Iland</a><a href="produk.php">Produk</a><a href="tentang.php">Tentang</a><a href="auth/login.php" class="nav-cta">Admin Login</a>
</div></div>
<section class="section"><div class="container">
<div class="section-head"><div><span class="badge">CATALOG</span><h1>Semua produk</h1><p>Pilih favoritmu untuk momen yang lebih manis.</p></div></div>
<div class="card"><form method="GET"><label>Cari produk</label><input type="text" name="keyword" placeholder="Contoh: brownies" value="<?= htmlspecialchars($keyword); ?>"><button type="submit" class="btn">Cari produk</button></form></div>
<div class="grid">
<?php $has=false; while ($row=mysqli_fetch_assoc($query)): $has=true; ?>
<article class="card product-card"><img src="uploads/produk/<?= htmlspecialchars($row['gambar']); ?>" class="product-image" alt="<?= htmlspecialchars($row['nama']); ?>">
<div class="product-body"><span class="badge"><?= htmlspecialchars($row['kategori']); ?></span><h3><?= htmlspecialchars($row['nama']); ?></h3><p><?= htmlspecialchars($row['deskripsi']); ?></p><div class="price">Rp <?= number_format($row['harga'],0,',','.'); ?></div><br><a href="detail.php?id=<?= $row['id']; ?>" class="btn btn-small">Lihat detail</a></div></article>
<?php endwhile; if(!$has): ?><div class="card empty" style="grid-column:1/-1">Produk yang kamu cari belum ditemukan.</div><?php endif; ?>
</div></div></section>
<footer class="footer">Izna Iland · Sweet moments, beautifully made.</footer></body></html>